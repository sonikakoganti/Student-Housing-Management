package CT;
import databaseconnection.*;
import java.sql.*;

public class  Details
{

static Connection con1=null;
static Statement st1=null;







public static String[] getHouse(String hid) {
		String[] res=new String[7];
			try{
			con1 = databasecon.getconnection();
			st1 = con1.createStatement();
			 String sql=null;;
			sql="select * from property where id='"+hid+"' ";
			System.out.println(sql);
			ResultSet rs=null;
			rs=st1.executeQuery(sql);

			if(rs.next())
			{
				res[0]=rs.getString("htype");
				res[1]=rs.getString("streetname");
				res[2]=rs.getString("city");
				res[3]=rs.getString("Description");
				res[4]=rs.getString("Number_of_rooms");
				res[5]=rs.getString("Rent_per_month");
				res[6]=rs.getString("property_owner_userid");


			}
			
			}
				catch(Exception e){
					System.out.println(e);
				}
				finally{
					try{
					con1.close();
					st1.close();
			//		rs.close();
					}
					catch(Exception e){
					System.out.println(e);
					}
				}
				return res;
	}




public static String getEmail(String tab, String userid) {
		String res="";
			try{
			con1 = databasecon.getconnection();
			st1 = con1.createStatement();
			 String sql=null;;
			sql="select * from "+tab+" where userid='"+userid+"' ";
			System.out.println(sql);
			ResultSet rs=null;
			rs=st1.executeQuery(sql);

			if(rs.next())
			{
				res=rs.getString("email");

			}
			
			}
				catch(Exception e){
					System.out.println(e);
				}
				finally{
					try{
					con1.close();
					st1.close();
			//		rs.close();
					}
					catch(Exception e){
					System.out.println(e);
					}
				}
				return res;
	}







	public static void main(String[] args) 
	{
	


	}

}



