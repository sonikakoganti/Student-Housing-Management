package CT;
import databaseconnection.*;
import java.sql.*;
import java.io.*;

public class SkipImage {
public static void main(String hid) {
try{
	
	Connection con =  databasecon.getconnection();
			
	PreparedStatement ps=con.prepareStatement("insert into hostelpics(hid,pic) values(?,?)");
		
	FileInputStream fin=new FileInputStream("hostel.jpg");
		
	ps.setString(1,hid);
	ps.setBinaryStream(2,fin,fin.available());

	int i=ps.executeUpdate();
	System.out.println(i+" records affected");
	con.close();
			
}catch (Exception e) {e.printStackTrace();}
}

	public static void main(String[] args) 
	{
		SkipImage.main("111111");
	}



}

