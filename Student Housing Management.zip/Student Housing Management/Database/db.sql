/*
SQLyog Community v11.52 (32 bit)
MySQL - 5.5.30 : Database - slms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`slms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `slms`;

/*Table structure for table `bookings` */

DROP TABLE IF EXISTS `bookings`;

CREATE TABLE `bookings` (
  `SNO` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `HouseId` varchar(100) DEFAULT NULL,
  `StudentName` varchar(100) DEFAULT NULL,
  `StudentUserid` varchar(100) DEFAULT NULL,
  `STATUS` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SNO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `property` */

DROP TABLE IF EXISTS `property`;

CREATE TABLE `property` (
  `id` varchar(100) NOT NULL DEFAULT '',
  `Htype` varchar(100) DEFAULT NULL,
  `Number_of_rooms` varchar(100) NOT NULL,
  `Rent_per_month` varchar(100) DEFAULT NULL,
  `streetname` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zipcode` varchar(100) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `AptNo` varchar(100) DEFAULT NULL,
  `property_owner_name` varchar(100) DEFAULT NULL,
  `property_owner_userid` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `book_status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `propertymaintainer` */

DROP TABLE IF EXISTS `propertymaintainer`;

CREATE TABLE `propertymaintainer` (
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Email` varchar(100) NOT NULL,
  `CellNumber` varchar(100) DEFAULT NULL,
  `UserId` varchar(100) NOT NULL DEFAULT '',
  `Password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `propertyowner` */

DROP TABLE IF EXISTS `propertyowner`;

CREATE TABLE `propertyowner` (
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Email` varchar(100) NOT NULL,
  `CellNumber` varchar(100) DEFAULT NULL,
  `UserId` varchar(100) NOT NULL DEFAULT '',
  `Password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `propertypictures` */

DROP TABLE IF EXISTS `propertypictures`;

CREATE TABLE `propertypictures` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(10) DEFAULT NULL,
  `pic` longblob,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `rentingstudent` */

DROP TABLE IF EXISTS `rentingstudent`;

CREATE TABLE `rentingstudent` (
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Email` varchar(100) NOT NULL,
  `CellNumber` varchar(100) DEFAULT NULL,
  `UserId` varchar(100) NOT NULL DEFAULT '',
  `Password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
